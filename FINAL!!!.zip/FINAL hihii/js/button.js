function index()
{
	  window.location = "index.html";
}
function abt()
{
	  window.location = "about.html";	
}
function cntct()
{
	  window.location = "contact.html";	
}
function abtus()
{
	  window.location = "aboutus.html";	
}
function fts()
{
	  window.location = "features.html";	
}
function ref()
{
	  window.location = "references.html";	
}
function gall()
{
	  window.location = "gallery1.html";	
}